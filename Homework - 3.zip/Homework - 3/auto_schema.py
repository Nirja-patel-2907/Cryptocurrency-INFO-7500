import subprocess
import json
from groq import Groq

def get_block_sample():
    hash_result = subprocess.run(
        ["/usr/local/bitcoin/bin/bitcoin-cli", "getblockhash", "1"],
        capture_output=True, text=True
    )
    block_hash = hash_result.stdout.strip()
    block_result = subprocess.run(
        ["/usr/local/bitcoin/bin/bitcoin-cli", "getblock", block_hash, "2"],
        capture_output=True, text=True
    )
    return json.loads(block_result.stdout.strip())

def generate_schema_code(block_json):
    client = Groq(api_key="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")
    
    prompt = f"""Write Python code to auto-generate a SQL schema from a JSON object.
The code should:
1. Take a JSON object as input
2. Analyze all fields and their types
3. Generate appropriate CREATE TABLE SQL statements
4. Handle nested objects as separate tables with foreign keys
5. Print the generated SQL schema

Use this JSON object as the example input:
{json.dumps(block_json, indent=2)}

Return only the Python code, nothing else."""

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

print("Fetching block from bitcoind...")
block_json = get_block_sample()
print("Asking LLM to write schema generation code...")
code = generate_schema_code(block_json)
print("\nGenerated Code:")
print(code)

with open("generated_schema_code.py", "w") as f:
    f.write(code)
print("\nCode saved to generated_schema_code.py")
